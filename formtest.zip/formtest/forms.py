# dwitter/forms.py

from django import forms
from common.forms import C2Form
from resourcehandlers.models import ResourceHandler
from utilities.logger import ThreadLogger

logger = ThreadLogger(__name__)

def generate_options_for_resource_handlers():
    # this shows them all
    rts = ResourceHandler.objects.all()
    # need to get self or requests in here

    #five_minutes_ago = datetime.now() - timedelta(minutes=5)
    #current_user_profile = UserProfile.objects.filter(last_activity_time__gte=five_minutes_ago).first()
    
    #envs = Environment.objects_for_profile()
    #list_of_envs = [env.resource_handler for env in envs if env.resource_handler and env.resource_handler.resource_technology.type_slug in ['aws', 'azure_arm']]
    #list_of_envs = [env.resource_handler for env in envs if env.resource_handler and env.resource_handler.resource_technology.type_slug in ['aws']]
    #rts = set(list_of_envs)
    # only AWS type RH
    options = []
    for r in rts:
        #if r.type_slug == "aws":
        options.append((r.id, r.name))

    return options



class ResourceHandlerForm(C2Form):
    
    rh_choices = generate_options_for_resource_handlers()
    logger.info("rh_choices=", rh_choices)
    my_attrs = {"style": "width:60%"}
    resourceHandler = forms.CharField(
        label="Choose a Resource Handler",
        required=True,
        widget=forms.Select(choices=rh_choices, attrs=my_attrs),
    )

    def save(self, request):
        """
        Validates posted form.
        """

        resourceHandler = self.cleaned_data.get("resourceHandler")

        return True