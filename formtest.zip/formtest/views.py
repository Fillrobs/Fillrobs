import json
import requests
from django.shortcuts import redirect
from django.shortcuts import render
from .forms import ResourceHandlerForm


def dashboard(request):
    if request.method == "POST":
        form = ResourceHandlerForm(request.POST)
        if form.is_valid():
            formtest = form.save(commit=False)
            formtest.user = request.user
            formtest.save()
            return redirect("templates:dashboard")
    form = ResourceHandlerForm()        
    return render(request, "formtest/templates/special.html", {"form": form})