from common.methods import set_progress
from orders.models import Order
#from utilities.servicenow_api import ServiceNowAPI
from utilities.models import ConnectionInfo


"""
SNOO Service Request Queue
~~~~~~~~~~~~~~~~~~~~~~~~~
Syncs CloudBolt Order Approval status with SNOO Approval status.
Based off of unique id sent to SNOO when Order is submitted.

Version Req.
~~~~~~~~~~~~
CloudBolt 9.0
"""

#########################
### Settings Override ###

### Status Options ###
"""
Response field from SNOO.
'stage', 'request_state', 'approval' are options often used.
'approval' is default setting
'order_approve' and 'order_deny' are CloudBolt specific and required.
Example: status_levels = {'order_approve':{'approval': ['approved']},'order_deny':{'approval': ['rejected']}}
"""

### SNOOw Approval Status Field ###
"""
set_approval_field()
Default is 'approval'
Example: ServiceNowAPI().set_approval_field('stage')
"""
def request_snoo(data, conn, url, logger=None):
    """
    Make REST call and return the response
    """
    headers = {"Content-Type": "application/json", "Accept": "application/json"}
    #response = requests.post(
    #    url=url,
    #    data=data,
    #    auth=(conn.username, conn.password),
    #    headers=headers
    #)
    response = requests.get(
        url=url,
        auth=(conn.username, conn.password),
        headers=headers
    )
    logger.info('Response from SNOO:\n{}'.format(response.content))
    return response


def get_snoo_status(cmp_order_id):
    conn = ConnectionInfo.objects.get(name='localhost_mysql')
    
    snoo_url = "{}://{}:{}".format(conn.protocol, conn.ip, conn.port)

    url = snoo_url + "/readorder.php?cmp_order_id={cmp_order_id}".format(cmp_order_id=cmp_order_id)
    response = request_snoo("NULL", conn, url, logger=logger)
    if response.status_code != 200:
        err = (
            'Failed to Get SNOO Record, response from '
            'SNOO:\n{}'.format(response.content)
        )
        return err

    return response



def run(job=None, logger=None, **kwargs):

    set_progress("Running Remedy ticket queue manager")

    # Get all PENDING orders
    pending_orders = Order.objects.filter(status="PENDING")

    # If there are any pending orders, begin calling ServiceNow for the corresponding order item
    if pending_orders:

        #servicenow = ServiceNowAPI()

        # Override CloudBolt ServiceNow status checks here
        # servicenow.set_status_option(status_levels=status_levels)
        # servicenow.set_approval_field('approval')

        """
        Loop through pending orders which have a PENDING status.
        Update status to be the status which has been set in ServiceNow
        """
        for order in pending_orders:
            # Here we get the first order item as this is the one we're using to get the Pending Status attribute
            order_item = order.orderitem_set.first()
            bp_order_item = order_item.blueprintorderitem
            # update order status. Default to pending.
            #status_message = servicenow.update_order_status(bp_order_item)
            cmp_order_id = order.id
            getOrderStatus = get_snoo_status(cmp_order_id)
            order_status = getOrderStatus["order_status"]
            logger.info(f"Order Id {cmp_order_id} and status = {order_status}")
            if order_status == 'APPROVED':
                order.status = 'APPROVED'
                order.save()

            set_progress(f"Order Id {cmp_order_id} and status = {order_status}")

    return "SUCCESS", "", ""