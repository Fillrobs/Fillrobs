from django.views.generic import ListView, CreateView, UpdateView
from django.urls import reverse_lazy
from .models import Person
from resources.models import Resource
from extensions.views import report_extension

@report_extension(title="Dropdown Example")
def dropdown_example(request, obj_id):
    class PersonListView(ListView):
        model = Person
        context_object_name = 'people'

    class PersonCreateView(CreateView):
        model = Person
        fields = ('name', 'birthdate', 'country', 'city')
        success_url = reverse_lazy('person_changelist')

    class PersonUpdateView(UpdateView):
        model = Person
        fields = ('name', 'birthdate', 'country', 'city')
        success_url = reverse_lazy('person_changelist')
    return render(
        request,
        "dropdown_example/templates/table.html",
    )     