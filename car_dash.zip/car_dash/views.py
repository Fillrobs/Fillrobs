from django.shortcuts import render

from extensions.views import dashboard_extension


@dashboard_extension(title="car_dash_dashboard_0", description="")
def function_0(request):
    pass
