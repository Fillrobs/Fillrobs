
from extensions.views import report_extension, ReportExtensionDelegate
from common.methods import set_progress
import requests
import sys


class detect_role_Delegate(ReportExtensionDelegate):
    def should_display(self):

        can_view = self.viewer.is_super_admin
        if can_view == False:
            profile = request.get_user_profile()
            can_view = self.viewer.is_customer_admin        
        return 

@report_extension(title="Detect Role", delegate=detect_role_Delegate)
def detect_role(request):
    profile = request.get_user_profile()
    set_progress(f"user profile is {}",format(profile) )
    return "","",""