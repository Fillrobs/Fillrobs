from extensions.views import tab_extension, TabExtensionDelegate
from infrastructure.models import CustomField
from orders.models import CustomFieldValue
from resourcehandlers.vmware.models import VsphereResourceHandler


class RecTabDelegate(TabExtensionDelegate):
    def should_display(self):
        rh = self.instance.resource_handler
        if rh:
            rh = rh.cast()
        if isinstance(rh, VsphereResourceHandler):
            return True
        return False


@tab_extension(
    model=Server,
    title="Rec Scheduler",
    description="Rec Schedule Tab",
    delegate=RecTabDelegate,
)
def create_recurring_job():
    cf = CustomField.objects.filter(name="rec_schedule").first()
    if not cf:
        from .rec_utilities import setup_rec_schedule

        setup_rec_schedule()
    return
