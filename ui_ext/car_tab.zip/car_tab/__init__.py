"""
This extension adds an additional tab on Cars to show Extra options
"""
