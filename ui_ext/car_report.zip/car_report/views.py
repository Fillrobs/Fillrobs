from django.shortcuts import render
from resources.models import Resource
from extensions.views import report_extension


@report_extension(title="Car Stock Report")
def car_table_report(request):
    """
    This shows a list of the Cars in the Custom Resource Type cars

    """

    # Show table
    show_table = True

    column_headings = [
        "ID",
        "Registration",
        "Manufacturer",
        "Logo",
        "Model",
        "Engine",
        "Colour",
    ]

    rows = []
    carstock = Resource.objects.filter(resource_type__name="car").all()
    # carstock = {"car_id": 1, "name": "abc", "manufid": 1, "car_modelid": 4}

    for car in carstock:
        # Each row is a tuple of cell values
        st = car.get_resource_dict()["status"]
        if st == "ACTIVE":
            modelid = car.car_modelid
            car_details = Resource.objects.filter(
                resource_type__name="car_model", id=modelid
            ).first()
            try:
                car_details_manuf = car_details.manuf
            except AttributeError:
                car_details_manuf = "None"

            try:
                car_details_name = car_details.name
            except AttributeError:
                car_details_name = "None"

            car_details_logo = car_details_manuf.lower()
            car_details_logo = car_details_logo.replace(" ", "")
            rows.append(
                (
                    car.car_id,
                    car.name,
                    car_details_manuf,
                    car_details_logo,
                    car_details_name,
                    car.car_engine_size,
                    car.car_colour,
                )
            )

    return render(
        request,
        "reports/table.html",
        dict(
            show_table=show_table,
            pagetitle="Car Stock Report",
            report_slug="Car Stock Report",
            table_caption="",
            column_headings=column_headings,
            rows=rows,
        ),
    )
