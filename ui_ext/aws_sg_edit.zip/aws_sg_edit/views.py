import time
import os
import json

from django.core.exceptions import PermissionDenied
from django.shortcuts import render

from common.methods import columnify
from extensions.views import dashboard_extension

from utilities.decorators import dialog_view
from resourcehandlers.aws.models import AWSHandler
from extensions.views import report_extension

from extensions.views import admin_extension, tab_extension, TabExtensionDelegate
from infrastructure.models import CustomField, Environment
from resourcehandlers.models import ResourceHandler
from resourcehandlers.aws.models import AWSHandler
from utilities.permissions import cbadmin_required
import boto3 
from botocore.exceptions import ClientError
from utilities.logger import ThreadLogger

logger = ThreadLogger(__name__)


# aws client
def get_aws_client(resource=None, service_name=None):
    '''
        Gets the client based on the service name and resource passed
    '''
    rh = AWSHandler.objects.get(id=resource.rh_id)

    client = rh.get_boto3_client(
        service_name=service_name,
        region_name=resource.s3_bucket_region
    )
    return client


#@report_extension
@tab_extension(model=Environment, title='AWS Security Group Editor', description='Used to edit AWS Security Group data')
def aws_sg_edit(request, obj_id):
    """
    View for managing the AWS Security Groups
    """
    '''
    profile = request.get_user_profile()
    env = Environment.objects.get(id=obj_id)
    #env_sec_groups = env.sec_groups
    #env = Environment.objects.filter(
    #    resource_handler__resource_technology__name="Amazon Web Services").first()
    rh = env.resource_handler.cast()
    region = 'ap-southeast-1'
    ec2_client = boto3.client('ec2',
                              region_name=region,
                              aws_access_key_id=rh.serviceaccount,
                              aws_secret_access_key=rh.servicepasswd
                              )
    column_headings = [
        "AWS Group Name",
        "CIdr IP",
        "From Port",
        "To Port",
        "IP Protocol",
        "Description",
        "VPCID",
        ]

    rows = []
    ec2secgr = ec2_client.describe_security_groups()

    for e in ec2secgr["SecurityGroups"]:
           rows.append(
                        (
                            e["GroupName"], 
                            e["IpPermissions"][0]["IpRanges"][0]["CidrIp"],
                            e["IpPermissions"][0]["FromPort"], 
                            e["IpPermissions"][0]["ToPort"], 
                            e["IpPermissions"][0]["IpProtocol"], 
                            e["Description"], 
                            e["VpcId"]
                        )
           )
    '''
    column_headings = [
        "AWS Group Name",
        "CIdr IP",
        "From Port",
        "To Port",
        "IP Protocol",
        "Description",
        "VPCID",
        ]

    rows = []
    env = Environment.objects.get(id=obj_id)
           
    return render(
        request,
        "aws_sg_edit/templates/aws_sg_edit.html",
        dict(
            env=env,
            pagetitle="AWS Security Group",
            table_caption="Shows AWS Security Group Data",
            column_headings=column_headings,
            rows=rows,
        ),
    )

