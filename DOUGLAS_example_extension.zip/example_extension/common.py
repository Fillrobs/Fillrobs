"""
Common code for related plugins
"""
