###############################################################################
# Do NOT change these values, they are derived from the module
BASE_NAME = __package__.split(".")[-1]
SETTINGS_FILE = __file__
TEMPLATE_DIR = f"{BASE_NAME}/templates"
STATIC_DIR = f"{BASE_NAME}/static"
###############################################################################

# Admin Page Extension Details
ADMIN_PAGE_TITLE = "Example Admin Extension"
ADMIN_PAGE_DESC = "Example Admin Extension Description"

PYTHON_PACKAGES = [
    # "python-slugify==5.0.2",
]

# https://github.com/ajaxorg/ace/wiki/Configuring-Ace#editor-options
# Do not set the mode option, it will be auto determined based on the file extension
EDITOR_DEFAULTS = {
    "enableBasicAutocompletion": True,
    "cursorStyle": "ace",
    "displayIndentGuides": True,
    "fontSize": 12,
    "highlightActiveLine": True,
    "keyboardHandler": "ace/keyboard/vim",
    "readOnly": False,
    "showGutter": True,
    "showLineNumbers": True,
    "showPrintMargin": True,
    "tabSize": 4,
    "theme": "ace/theme/solarized_light"
}
#ack was here