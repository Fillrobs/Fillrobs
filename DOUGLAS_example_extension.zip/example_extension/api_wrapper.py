"""
Sample API Wrapper
"""
import requests
from utilities.helpers import get_ssl_verification
from utilities.models import ConnectionInfo
from utilities.logger import ThreadLogger
from .xui_settings import (
    BASE_NAME,
)

logger = ThreadLogger(__name__)


class XUIAPIWrapper(object):
    """"""

    def __init__(self):
        """
        Very simply initialization for the class.
        No arguments are required, the Connection Info object is looked up.
        """
        self.connection_info = self._get_connection_info()
        # configure the base url from the attributes in the Connection Info object
        self.BASE_URL = f"{self.connection_info.protocol}://{self.connection_info.ip}:{self.connection_info.port}/api/v1"
        # the headers can also be defined in the Connection Info object
        self.headers = {"Content-Type": "application/json"}
        # create a placeholder to store the token
        self.token = ""

    def _get_connection_info(self):
        # get the Connection Info object
        ci_defaults = {
            "ip": "0.0.0.0",
            "protocol": "https",
            "port": 443,
            "username": "example_svc_acct",
            "password": "",
        }
        ci, _ = ConnectionInfo.objects.get_or_create(
            name=BASE_NAME,
            defaults=ci_defaults,
        )
        return ci

    def _run(self, method, url, auth=None, json=None, params=None, headers=None):
        """
        Generic run method for the Requests library

        :param url: URL for the new :class:`Request` object.
        :param auth: (optional)Basic auth `Tuple` object.
        :param json: (optional) json data to send in the body of the :class:`Request`.
        :param params: (optional) dictionary of parameters for the request.
        :param headers: (optional) dictionary of header options for the request.
        :return: :class:`Response <Response>` object
        """
        if not headers:
            headers = self.headers
        response = requests.request(
            method,
            url,
            auth=auth,
            json=json,
            params=params,
            headers=headers,
            verify=get_ssl_verification(),
        )
        if response.status_code not in [200, 201, 204]:
            # The API documentation of your 3rd party tool should define the error codes and associated messaging.
            # Add additional codes below for customized error handling messages
            if response.status_code in [400]:
                raise Exception(
                    f"{response.text} The specified request returned a bad request error, requires an argument or \
                    requires only a single argument"
                )
            raise Exception(
                f"Return Code: {response.status_code}, Response Text: {response.text}s"
            )

        return response

    def _get(self, url, params=None, headers=None):
        return self._run("GET", url, params=params, headers=headers)

    def _post(self, url, json=None, params=None, headers=None):
        return self._run("POST", url, json=json, params=params, headers=headers)

    def _patch(self, url, json=None, params=None, headers=None):
        return self._run("PATCH", url, json=json, params=params, headers=headers)

    def _delete(self, url, json=None, headers=None):
        return self._run("DELETE", url, json=json, headers=headers)

    def login(self):
        url = self.AUTH_URL
        # create a copy of the header and append the auth specific header options from the API documentation
        headers = self.headers.copy()
        headers["Content-Type"] = "application/x-www-form-urlencoded"
        auth = (self.connection_info.username, self.connection_info.password)
        response = self._run("POST", url=url, auth=auth, headers=headers)
        r_json = response.json()
        self.token = r_json.get("token")
        self.headers["Authorization"] = f"Bearer {self.token}"
        return response

    def list_objects(self, obj_type):
        url = f"{self.BASE_URL}/{obj_type}"
        resources = []
        params = {"order_by": "name"}
        response = self._get(url, params=params).json()
        for resource in response["resources"]:
            resources.append(resource)
        next = response["pagination"]["next"]
        while next:
            response = self._get(next, params=params).json()
            for resource in response["resources"]:
                resources.append(resource)
        return resources

    def create_object(self, obj_type, name=None, params={}):
        url = f"{self.BASE_URL}/{obj_type}"
        if name:
            params["name"] = name
        response = self._post(url, params=params).json()
        return response

    def update_object(self, obj_type, name, guid, params={}):
        url = f"{self.BASE_URL}/{obj_type}/{guid}"
        params["name"] = name
        response = self._patch(url, params=params).json()
        return response

    def delete_object(self, obj_type, guid):
        url = f"{self.BASE_URL}/{obj_type}/{guid}"
        response = self._delete(url).json()
        return response

    def list_organizations(self):
        """
        List ALL Organizations
        """
        return self.list_objects(obj_type="organizations")

    def create_organization(self, name):
        """
        Arguments:
            name: (STR) Required: New Organization name
        """
        return self.create_object(obj_type="organizations", name=name)
