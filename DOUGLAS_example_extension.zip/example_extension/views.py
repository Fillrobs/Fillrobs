from django.shortcuts import render

from extensions.views import admin_extension
from tabs.views import TabGroup
from utilities.decorators import json_view
from utilities.logger import ThreadLogger

from .api_wrapper import XUIAPIWrapper
from .xui_settings import (
    ADMIN_PAGE_DESC,
    ADMIN_PAGE_TITLE,
    BASE_NAME,
    EDITOR_DEFAULTS,
    SETTINGS_FILE,
    TEMPLATE_DIR,
)

logger = ThreadLogger(__name__)


@json_view
def update_file(request):
    file_path = request.POST.get("file_path", None)
    file_content = request.POST.get("file_content", None)
    f = open(file_path, "w")
    f.write(file_content)
    f.close()


@admin_extension(title=ADMIN_PAGE_TITLE, description=ADMIN_PAGE_DESC)
def admin_page(request):
    wrapper = XUIAPIWrapper()

    f = open(SETTINGS_FILE, "r")
    settings_content = f.read()
    f.close()

    admin_context = {
        "title": ADMIN_PAGE_TITLE,
        "tabs": TabGroup(
            template_dir=TEMPLATE_DIR,
            context={
                "endpoint": wrapper.connection_info,
                "editor_id": BASE_NAME,
                "editor_defaults": EDITOR_DEFAULTS,
                "file_path": SETTINGS_FILE,
                "file_content": settings_content,
            },
            request=request,
            tabs=[
                (("Overview"), "overview", {}),
                (("Files"), "files", {}),
                (("Settings"), "settings", {}),
                (("Inputs"), "inputs", {})
            ],
        ),
    }
    return render(request, f"{TEMPLATE_DIR}/admin_page.html", admin_context)
