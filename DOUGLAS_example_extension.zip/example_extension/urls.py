from django.conf.urls import url
from . import views
from .xui_settings import BASE_NAME

xui_urlpatterns = [
    url(
        r"^ajax/" + BASE_NAME + "/update_file/$", views.update_file, name="update_file"
    ),
]
